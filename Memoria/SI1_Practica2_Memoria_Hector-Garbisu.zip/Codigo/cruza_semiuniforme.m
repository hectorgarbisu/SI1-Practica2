function [pop] = cruza_semiuniforme(pop)
end
% cruce = ['onepoint' 'twopoint' 'uniforme' 'semiuniforme'];
