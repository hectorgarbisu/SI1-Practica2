function [pop]  = esca(pop,fitn,generacion,maxgen)
end

% sel = ['truncamiento' 'rwsr' 'sus' 'torneo'];